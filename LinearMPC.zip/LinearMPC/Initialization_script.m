% Linear Control Model
clc; clear;

%parameters of system part1
l_cm = 0.015; %[m] Distance between the pivot point and the center of mass of helicopter
m_heli = 0.479; %[kg] Total moving mass of the helicopter
J_eq_p = 0.0172; %[kg/m^2] Moment of inertia about the pitch axis
J_eq_y = 0.0210; %[kg/m^2] Moment of inertia about the yaw axis
g = 9.81; %[m/s^2] Acceleration due to gravity on planet earth
 
%parameters of system part2
K_pp = 0.0556; %[Nm/V] Torque constant on pitch axis from pitch motor/propeller
K_yy = 0.21084; %[Nm/V] Torque constant on yaw axis from yaw motor/propeller
K_py = 0.005; %[Nm/V] Torque constant on pitch axis from yaw motor/propeller
K_yp = 0.15; %[Nm/V] Torque constant on yaw axis from pitch motor/propeller
B_p = 0.01; %Damping friction factor about pitch axis
B_y = 0.08; %Damping friction factor about yaw axis


%operating point for states
tt_op = -10*pi/180;
f_op = pi/2;
w_tt_op =0;
w_f_op =0;

% operating point for Control inputs
 V_mp_op = (K_yy* m_heli*g*cos(tt_op)*l_cm  )/((K_yy*K_pp-K_yp*K_py));
 V_my_op = (K_yp* V_mp_op)/K_yy ;  
 
% Change to descrete time model
A_c = [0,0,1,0;...
       0,0,0,1;...
       (m_heli*g*l_cm*sin(tt_op))/(J_eq_p + m_heli*l_cm^2)...
       ,0,-B_p/(J_eq_p+m_heli*l_cm^2),0;...
       (K_yp * V_mp_op - K_yy*V_my_op) * ((m_heli * 2* (l_cm)^2 * cos(tt_op) * sin(tt_op))/...
       (J_eq_y + m_heli*(l_cm)^2*(cos(tt_op)^2))^2),0,0,-B_y/(J_eq_y+m_heli*l_cm^2*(cos(tt_op)^2))];
B_c = [0,0;
        0,0;
        K_pp/(J_eq_p + m_heli* l_cm^2),-K_py/(J_eq_p+ m_heli*l_cm^2);...
        K_yp/(J_eq_y + m_heli*(l_cm)^2*(cos(tt_op)^2)),-K_yy/(J_eq_y+m_heli*l_cm^2*(cos(tt_op)^2))];
C_c = [1,0,0,0;0,1,0,0];
 dt = 0.01;  % time sampling
 sys = ss(A_c, B_c, C_c, 0);
 ds = c2d(sys,dt);
 A = ds.a;
 B = ds.b;
 C = ds.c;
 
 
%Kalman Filter
G = eye(4); %this is difficult to know in reality. So assume it is identity matrix (i.e. 1)
H = zeros(2,4);
plant = ss(A_c,[B_c,G],C_c,0); %D = 0 since it is not present

%%
W = diag([5e1,7e1,8e1,6e1]); %process
V = diag([0.1,0.1]); %measurement noise

%calculate the kalman gain L
[kalmf,L,P,M] = kalman(plant,W,V);

